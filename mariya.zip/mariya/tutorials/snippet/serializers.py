from rest_framework import serializers
# from talk.models import Post


class PostSerializer(serializers.Serializer):

    path = serializers.CharField()
    number = serializers.CharField()


class PlaceSerializer(serializers.Serializer):

    fields = '__all__'