from django.shortcuts import render

from snippet.serializers import *
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import pandas as pd
import numpy as np
import sys
# import mysql.connector
import re
import urllib
import os

class SnippetList(APIView):
	def post(self, request, format=None):
		serializer = PostSerializer(data=request.data)
		if serializer.is_valid():
			import pandas as pd
			import numpy as np
			import sys
			# import mysql.connector
			import re
			import urllib
			import os
			# master_file_path = sys.argv[1]
			# disc_file_path = sys.argv[2]
			# user_result_path = sys.argv[3]
			# user_id= sys.argv[4]
			def master_df_cleaning(master_df_path):
				"""
				this function is for retriving and cleaning the master dataset file
				it will accept the master file path as a string
				and will return the master dataset as a pandas dataframe
				"""
				# read the excel file and set the index to be the RS ID
				master_df = (
					pd.read_excel(master_df_path, index_col=[0, 1]).reset_index().set_index("RS ID")
				)
				# Clean the trait column making it striping out whitespace, replacing spaces with an underscore, and making it lowercase
				master_df["Trait"] = master_df["Trait"].apply(
					lambda x: str(x).strip().replace(" ", "_").replace("-", "_").lower()
				)
				# cleaning zygosity column making it replasing homo with hom removing whitespasse and lowercase
				master_df["Zygosity"] = master_df["Zygosity"].apply(
					lambda x: str(x).replace("Homo", "hom").lower().replace(" ", "")
				)
				return master_df
			def desc_df_cleaning(desc_df_path):
				"""
				this function is for retriving and cleaning the descriptions dataset file
				it will accept the description file path as a string
				and will return the descriptions dataset as a pandas dataframe
				"""
				# read the excel file and reset the index
				disc_df = pd.read_excel(desc_df_path, index_col=[0]).reset_index()
				# Clean the trait column making it striping out whitespace, replacing spaces with an underscore, and making it lowercase
				disc_df["Trait"] = disc_df["Trait"].apply(
					lambda x: str(x).strip().replace(" ", "_").replace("-", "_").lower()
				)
				disc_df.set_index(["Trait", "Score"], inplace=True)
				## columns of interest
				col = [
					"Bar Arrow",
					"Bar Arrow_AR",
					"Description",
					"Description_AR",
					"Daily Intake",
					"Daily Intake_AR",
					"Recommendations",
					"Recommendations_AR",
					"Sources per 100 g",
					"Sources per 100 g_AR",
					"Roles",
					"Roles_AR",
					"Deficiency",
					"Deficiency_AR",
					"High consumption may lead to",
					"High consumption may lead to_AR",
					"General Information",
					"General Information_AR",
				]
				disc_df = disc_df.fillna("-")
				## url encode the values 
				disc_df=disc_df.applymap(lambda x : urllib.parse.quote(x))
				# copress the columns of interest into an object and transform it into a string. the string is stored at a column called data
				disc_df = (
					disc_df.groupby(["Trait", "Score"])[col]
					.apply(lambda x: x.to_dict())
					.reset_index(name="data")
					.set_index(["Trait", "Score"])
				)
				disc_df["data"] = disc_df["data"].apply(lambda x: str(x))
				disc_df["data"] = disc_df["data"].apply(
					lambda x: re.sub(r"\([^)]*\)", "'key'", x).replace("'", '"')
				)
				return disc_df
			def user_df_cleaning(user_result_path, master_df):
				"""
				this function is for retriving and cleaning the user result file
				it will accept the description file path as a string and the master dataset dataframe
				and will return the descriptions dataset as a pandas dataframe
				"""
				## read the excel file
				user_result = pd.read_excel(user_result_path)
				# define the columns of interest and rename them
				user_result = user_result[["avsnp150", "Otherinfo1"]]
				user_result.columns = ["RS ID", "Zygosity"]
				## Add missing columns with NaN values
				user_result["Trait"] = np.nan
				user_result["Genotype"] = np.nan
				user_result["Score"] = np.nan
				# set the index to be the RS ID
				user_result.set_index(["RS ID"], inplace=True)
				# Clean the trait column making it striping out whitespace, replacing spaces with an underscore, and making it lowercase
				user_result["Zygosity"] = user_result["Zygosity"].apply(
					lambda x: str(x).replace("Homo", "hom").lower().replace(" ", "")
				)
				# choose the genoms that we care about reffering to the master dataset
				cond2 = (
					user_result.reset_index()
					.set_index(["RS ID"])
					.index.isin(master_df.reset_index().set_index(["RS ID"]).index)
				)
				user_result = user_result[cond2]
				# attach the Trait, Genotype and the score using the master dataset
				cond1 = (
					master_df.reset_index()
					.set_index(["RS ID", "Zygosity"])
					.index.isin(user_result.reset_index().set_index(["RS ID", "Zygosity"]).index)
				)
				user_result = master_df[cond1]
				return user_result
			def create_ref_report(master_df):
				"""
				this function will create a ref report
				a user report with all results to be ref
				this ref report will be used to fill the missing ref values
				the function will accept the master dataset dataframe
				and will return the ref report as a dataframe
				"""
				# set a condtion that will catch ref values
				cond = (master_df["Zygosity"] == "Ref") | (master_df["Zygosity"] == "ref")
				reff_report_df = master_df[cond]
				return reff_report_df
			def create_full_user_report(user_result, master_df):
				"""
				this function will fill the missing reff values in the user result
				it will accept the user result as a dataframe and the master dataset dataframe
				and will return a completed user report with the missing ref values filled as a dataframe
				"""
				## create a reff user report
				reff_report_df = create_ref_report(master_df)
				# set a frame that will concate the missing ref values to the exsisting values
				frames = [
					user_result,
					reff_report_df[~reff_report_df.index.isin(user_result.index)],
				]
				result = pd.concat(frames)
				return result
			def calculate_prs(result):
				"""
				this function will calculate the Polygenic risk score
				for the scenario B cases
				this function will accept the full user report
				calculate the PRS
				and will return a user report with Trait score and missing data
				"""
				## create an index that have all the traits
				trait_index = set(result.reset_index().set_index(["Trait"]).index)
				# initiate an empty report for the data to be added to it
				report = pd.DataFrame(columns=["Trait", "Score", "data"])
				for trait in trait_index:
					df = (
						result.reset_index().set_index(["Trait"]).loc[trait]
					)  ## take a sub dataframe for a certian trait
					score = 0
					## if the sub dataframe was actually a dataframe, then itterate through it and sum whatever score in it
					if isinstance(df, pd.DataFrame):
						for row in df["Score"]:
							score = score + row
					# in case it was not, then it is a sceanario A case
					else:
						score = df["Score"]
					# append the result to report dataframe
					df = pd.DataFrame([[trait, score, np.nan]], columns=["Trait", "Score", "data"])
					report = report.append(df, ignore_index=True)
				return report
			def attach_desc(report, disc_df):
				"""
				this function will attach the data from descripon dataset onto the user result
				it will accept the user report and the description dataset both as dataframes
				and will return a completed user result to be stored in the database
				"""
				report = report.set_index(["Trait", "Score"])
				report = disc_df[disc_df.index.isin(report.index)]
				return report
			def store_prep(report, user_id):
				"""
				this function will prepare the user report to be stored in the database by extraction the column names and theier values dynamicly
				it will accept the completed user report and the user ID and will return the columns and their values respectvlly
				"""
				sql_col = tuple(report.reset_index().set_index("Trait").index)
				user_ID_col = "user_id"
				user_ID_col = (user_ID_col,)
				sql_col = user_ID_col + sql_col
				values_integrators = tuple()
				for col in sql_col:
					integrator = ("%s",)
					values_integrators = values_integrators + integrator
				values_integrators = str(values_integrators).replace("'", "")
				sql_col = str(sql_col).replace("'", "")
				sql_values = tuple(report.reset_index().set_index("data").index)
				user_ID = user_id
				user_ID = (user_ID,)
				sql_values = user_ID + sql_values
				sql_col, sql_values, values_integrators
				myClass = sql_col, sql_values, values_integrators
				return sql_col, sql_values, values_integrators
			def store_to_db(report, user_id, sql_host, sql_user, sql_pass, sql_db):

				"""
				this function is responsable for storing a user report to the database
				the function will accept the completed user report, user ID , and the database crids
				"""
					
				## generate columns and values
				sql_col, sql_values, values_integrators = store_prep(report, user_id)
				return sql_col, sql_values, values_integrators
				# return Response(sql_col)

				# result = store_prep()
				# response = Response(result, status=status.HTTP_200_OK)
				# return response

				# api will return sql_col, sql_values, values_integrators
				
				# connect to the database
				#mydb = mysql.connector.connect(
				#    host=sql_host, user=sql_user, password=sql_pass, database=sql_db,port=3306
				#)
				# it does sth I guess
				#mycursor = mydb.cursor()
				## the sql command that will match columns with values
				# sql = (
				#     f"INSERT INTO `wp_custom_user_report` {sql_col} "
				#     + f"VALUES {values_integrators}"
				# )
				#sql =f"INSERT INTO `wp_custom_user_report` {sql_col} VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
			 
				#val = sql_values
				#mycursor.execute(sql, val)
				#mydb.commit()  ## very important for changes to settle
				## print out the number of rows inserted
				print(mycursor.rowcount, "was inserted.")
			# def main(user_result_paths,user_ids):
				## catch the values passed from outside
				# master_file_path = sys.argv[1]
				# disc_file_path = sys.argv[2]

			master_file_path = 'masterV3.xls'	
			disc_file_path = 'descV4.xls'
			user_result_path = serializer.data['path'] #first parameter in api
			user_id = serializer.data['number'] #second parameter in api
			print(master_file_path)
			
			# retrive data from the excel files
			master_df = master_df_cleaning(master_file_path)
			desc_df = desc_df_cleaning(disc_file_path)
			user_result = user_df_cleaning(user_result_path, master_df)
			# forge the user report
			full_user_report = create_full_user_report(user_result, master_df)
			full_user_report = calculate_prs(full_user_report)
			full_user_report = attach_desc(full_user_report, desc_df)
			# store the report in the database
			a , b, c = store_to_db(full_user_report, user_id, "localhost", "shafra_wp", "MZLspj=j=8TGS", "shafra_wp")
			
			return Response({'sql_cols':a ,'sql_valuess': b,'values_integratorss': c})
				# remove uploaded file
				#os.remove(user_result_path)
				# a=10
				# b = 'abc'
				# return a,b
			# if __name__ == "__main__":
			print("sssss",serializer.data['path'])
			print("number",serializer.data['number'])
			
				#a='abc'
				#return a

			# return Response(serializer.data)
		return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

